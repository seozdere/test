-- ═══════════════════════════════════════════════════════════════════════════
--  ClassLog Pro — v3.2 Migration
--  • Öğretmen ders erişimi (subjects kolonu)
--  • Dönem yönetimi (cl_save_settings_v2 — esnek JSONB)
--  Supabase Dashboard → SQL Editor → Yapıştır → Run
-- ═══════════════════════════════════════════════════════════════════════════

-- ── 1. Öğretmen tablosuna subjects kolonu ekle ─────────────────────────────────
ALTER TABLE classlog_teachers ADD COLUMN IF NOT EXISTS subjects TEXT[] DEFAULT '{}';

-- ── 2. cl_authenticate: subjects dahil ────────────────────────────────────────
CREATE OR REPLACE FUNCTION cl_authenticate(p_username TEXT, p_password TEXT)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_teacher classlog_teachers%ROWTYPE;
    v_token   TEXT;
BEGIN
    DELETE FROM classlog_sessions WHERE expires_at < NOW();

    SELECT * INTO v_teacher FROM classlog_teachers
    WHERE username = lower(trim(p_username)) AND password = p_password;

    IF NOT FOUND THEN RETURN '{"ok":false,"reason":"wrong"}'::JSONB; END IF;
    IF NOT v_teacher.active THEN RETURN '{"ok":false,"reason":"inactive"}'::JSONB; END IF;

    v_token := encode(gen_random_bytes(32), 'hex');
    INSERT INTO classlog_sessions (teacher_id, token, expires_at)
    VALUES (v_teacher.id, v_token, NOW() + INTERVAL '12 hours');

    RETURN jsonb_build_object(
        'ok',            true,
        'session_token', v_token,
        'teacher', jsonb_build_object(
            'id',       v_teacher.id,
            'username', v_teacher.username,
            'name',     v_teacher.name,
            'role',     v_teacher.role,
            'classes',  v_teacher.classes,
            'subjects', COALESCE(v_teacher.subjects, '{}'),
            'active',   v_teacher.active
        )
    );
END;
$$;

-- ── 3. cl_list_teachers: subjects dahil ───────────────────────────────────────
CREATE OR REPLACE FUNCTION cl_list_teachers(p_token TEXT)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_caller classlog_teachers%ROWTYPE;
BEGIN
    v_caller := cl_check_session(p_token);
    IF v_caller.id IS NULL OR v_caller.role != 'admin' THEN RETURN '[]'::JSONB; END IF;
    RETURN (
        SELECT COALESCE(jsonb_agg(jsonb_build_object(
            'id', id, 'username', username, 'name', name,
            'role', role, 'classes', classes,
            'subjects', COALESCE(subjects, '{}'), 'active', active
        ) ORDER BY name), '[]'::JSONB)
        FROM classlog_teachers
    );
END;
$$;

-- ── 4. cl_save_teacher: subjects kaydeder ────────────────────────────────────
CREATE OR REPLACE FUNCTION cl_save_teacher(p_token TEXT, p_teacher JSONB)
RETURNS BOOLEAN LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_caller classlog_teachers%ROWTYPE;
    v_id     BIGINT;
BEGIN
    v_caller := cl_check_session(p_token);
    IF v_caller.id IS NULL OR v_caller.role != 'admin' THEN RETURN false; END IF;
    v_id := (p_teacher->>'id')::BIGINT;
    IF v_id IS NOT NULL THEN
        UPDATE classlog_teachers SET
            name     = p_teacher->>'name',
            username = lower(p_teacher->>'username'),
            role     = p_teacher->>'role',
            active   = (p_teacher->>'active')::BOOLEAN,
            classes  = ARRAY(SELECT jsonb_array_elements_text(p_teacher->'classes')),
            subjects = ARRAY(SELECT jsonb_array_elements_text(p_teacher->'subjects')),
            password = CASE WHEN p_teacher->>'password' IS NOT NULL AND p_teacher->>'password' != ''
                           THEN p_teacher->>'password' ELSE password END
        WHERE id = v_id;
    ELSE
        INSERT INTO classlog_teachers (username, password, name, role, active, classes, subjects)
        VALUES (
            lower(p_teacher->>'username'), p_teacher->>'password',
            p_teacher->>'name',
            COALESCE(p_teacher->>'role', 'teacher'),
            COALESCE((p_teacher->>'active')::BOOLEAN, true),
            ARRAY(SELECT jsonb_array_elements_text(p_teacher->'classes')),
            ARRAY(SELECT jsonb_array_elements_text(p_teacher->'subjects'))
        );
    END IF;
    RETURN true;
EXCEPTION WHEN unique_violation THEN RETURN false;
END;
$$;

-- ── 5. cl_save_settings_v2: Esnek JSONB blob (dönem sistemi için) ─────────────
CREATE OR REPLACE FUNCTION cl_save_settings_v2(p_token TEXT, p_settings JSONB)
RETURNS BOOLEAN LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_caller classlog_teachers%ROWTYPE;
BEGIN
    v_caller := cl_check_session(p_token);
    IF v_caller.id IS NULL OR v_caller.role != 'admin' THEN RETURN false; END IF;
    INSERT INTO classlog_storage (id, records, last_updated)
    VALUES ('__settings__', p_settings, NOW())
    ON CONFLICT (id) DO UPDATE SET records = EXCLUDED.records, last_updated = NOW();
    RETURN true;
END;
$$;

-- ── Tamamlandı ────────────────────────────────────────────────────────────────
SELECT 'ClassLog Pro v3.2 Migration tamamlandı ✅' AS durum;
